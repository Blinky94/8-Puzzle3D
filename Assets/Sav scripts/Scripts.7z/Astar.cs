﻿using System.Collections.Generic;
using System.Linq;
using System;

public class Astar
{
      private int D;
      private List<Node> currentList;
      private List<Node> goalList;
      private List<Node> openList;
      private List<Node> closedList;

      private Node SelectMinF(List<Node> listAdjacents)
      {
            Node minNode = new Node(null);

            var min = (from node in listAdjacents where node.F >= 0 select node).Min();
            var sortedNodes = from node in listAdjacents where node.F == min.F select node;

            foreach (var node in sortedNodes)
                  minNode = node;

            return minNode;
      }

      public int ManathanHeuristic(List<Node> currentList, List<Node> goalList)
      {
            //To do : compare 2 list and find the number of disressemblances
            return 0;
      }

      public Astar(List<Node> randomList, List<Node> goalList)
      {
            D = 1;

            this.currentList = randomList;
            this.goalList = goalList;

            openList = new List<Node>();
            openList.Add(start);

            closedList = new List<Node>();

            start.G = 0;
            start.H = 0;
            start.F = start.G + start.H;
      }

      private bool IsNodeInList(Node currentNode, List<Node> currentList)
      {
            bool IsInList = false;

            foreach (Node node in currentList)
            {
                  if (node == currentNode)
                        IsInList = true;
            }

            return IsInList;
      }

      private List<Node> GetAdjacentsNodes(Node current)
      {
            List<Node> listAdjacents = new List<Node>();

            return listAdjacents;
      }

      private List<Node> RewardPathFromEndToStart(Node toStart, Node fromGoal)
      {
            List<Node> listPath = new List<Node>();

            Node current = fromGoal;

            while (current != toStart)
            {
                  listPath.Add(current);
                  current = current.Parent;
            }

            return listPath;
      }

      public void Search(List<Node> currentList,List<Node> goalList)
      {
            bool stop = false;

            while (stop == false)
            {
                  Node currentNode = SelectMinF(openList);

                  if (currentNode == end)
                  {
                        RewardPathFromEndToStart(start, currentNode);
                        stop = true;
                  }
                  else if (openList.Count == 0)
                        stop = true;
                  else
                  {
                        if (IsNodeInList(currentNode, openList))
                        {
                              openList.Remove(currentNode);
                              closedList.Add(currentNode);
                        }

                        List<Node> listAdj = GetAdjacentsNodes(currentNode);

                        foreach (Node adjNode in listAdj)
                        {
                              if (IsNodeInList(adjNode, closedList))
                                    continue;
                              else if (!IsNodeInList(adjNode, openList))
                              {
                                    adjNode.G = currentNode.G + D;
                                    adjNode.H = ManathanHeuristic(currentList, goalList);
                                    adjNode.F = adjNode.G + adjNode.H;
                                    adjNode.Parent = currentNode;
                                    openList.Add(adjNode);
                              }
                              else if (IsNodeInList(adjNode, openList))
                              {
                                    foreach (Node nodeInlist in openList)
                                    {
                                          if (nodeInlist == adjNode)
                                          {
                                                adjNode.G = currentNode.G + D;

                                                if (adjNode.G < nodeInlist.G)
                                                {
                                                      adjNode.H = ManathanHeuristic(currentList, goalList);
                                                      adjNode.F = adjNode.G + adjNode.H;
                                                      adjNode.Parent = currentNode;
                                                      openList.Remove(nodeInlist);
                                                      openList.Add(adjNode);
                                                }
                                          }
                                    }
                              }
                        }
                  }
            }
      }  
}
