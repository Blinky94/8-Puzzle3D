﻿using UnityEngine;

public static class ChargeObjects
{
    public static void IntializeObjects ()
    {
        ObjType.LoadObjectInScene();
        Counter.Initialize();
    }
}
