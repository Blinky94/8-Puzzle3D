﻿using UnityEngine;
using UnityEngine.EventSystems;
using System.Collections.Generic;

public class AutoRes8 : MonoBehaviour, IPointerDownHandler,IPointerUpHandler
{
      public bool IsAutoRes, IsSolutionFound;
      public List<Node> listRandomPalets;
      public List<Node> listOrderedPalets;
      private int index;
      private List<List<Node>> listOfPossiblesPaletsMooves;

      void SetPossiblesPaletsMooves(int nullPaletIndex)
      {
            switch(nullPaletIndex)
            {
                  case 1:
                        listOfPossiblesPaletsMooves.Clear();

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[1],null,listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[4], listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[3],listRandomPalets[1],listRandomPalets[2],
                              null, listRandomPalets[4], listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });
                        break;
                  case 2:
                        listOfPossiblesPaletsMooves.Clear();

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              null,listRandomPalets[0],listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[4], listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[4],listRandomPalets[2],
                              listRandomPalets[3], null, listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[2],null,
                              listRandomPalets[3], listRandomPalets[4], listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });
                        break;
                  case 3:
                        listOfPossiblesPaletsMooves.Clear();

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],null,listRandomPalets[1],
                              listRandomPalets[3], listRandomPalets[4], listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[5],
                              listRandomPalets[3], listRandomPalets[4], null,
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });
                        break;
                  case 4:
                        listOfPossiblesPaletsMooves.Clear();

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              null,listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[0], listRandomPalets[4], listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[4], null, listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[6], listRandomPalets[4], listRandomPalets[5],
                              null, listRandomPalets[7], listRandomPalets[8]
                        });
                        break;
                  case 5:
                        listOfPossiblesPaletsMooves.Clear();

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],null,listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[1], listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[5], null,
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[7], listRandomPalets[5],
                              listRandomPalets[6], null, listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              null, listRandomPalets[3], listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });
                        break;
                  case 6:
                        listOfPossiblesPaletsMooves.Clear();

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],null,
                              listRandomPalets[3], listRandomPalets[4], listRandomPalets[2],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[3], null, listRandomPalets[4],
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[4], listRandomPalets[8],
                              listRandomPalets[6], listRandomPalets[7], null
                        });
                        break;
                  case 7:
                        listOfPossiblesPaletsMooves.Clear();

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              null, listRandomPalets[4], listRandomPalets[5],
                              listRandomPalets[3], listRandomPalets[7], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[4], listRandomPalets[5],
                              listRandomPalets[7], null, listRandomPalets[8]
                        });
                        break;
                  case 8:
                        listOfPossiblesPaletsMooves.Clear();

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[3], null, listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[4], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[4], listRandomPalets[5],
                              null, listRandomPalets[6], listRandomPalets[8]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[4], listRandomPalets[5],
                              listRandomPalets[6], listRandomPalets[8], null
                        });
                        break;
                  case 9:
                        listOfPossiblesPaletsMooves.Clear();

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[4], listRandomPalets[5],
                              listRandomPalets[6], null, listRandomPalets[7]
                        });

                        listOfPossiblesPaletsMooves.Add(new List<Node>()
                        {
                              listRandomPalets[0],listRandomPalets[1],listRandomPalets[2],
                              listRandomPalets[3], listRandomPalets[4], null,
                              listRandomPalets[6], listRandomPalets[7], listRandomPalets[5]
                        });
                        break;
            }
      }

      private int GetPositionNullInRandomList()
      {
            index = 0;

            for(int i = 0; i < listRandomPalets.Count;i++)                         
                  if (listRandomPalets[i].ListColliders == null)
                        index = i + 1;             
            
            return index;           
      }

      private void GetActualListOrder()
      {
            listRandomPalets.Clear();

            foreach (PaletName obj in ObjType.Plaque.GetComponentsInChildren<PaletName>())
            {
                  Node newNode = new Node(obj.paletName);
                  listRandomPalets.Add(newNode);
            }
      }

      void IPointerDownHandler.OnPointerDown(PointerEventData eventData)
      {
            ObjType.LoadObjectInScene();
            IsAutoRes = true;
            transform.GetComponent<UnityEngine.UI.Image>().color = Color.green;
            transform.GetComponentInChildren<UnityEngine.UI.Text>().color = Color.red;
            GetActualListOrder();
      }

      void IPointerUpHandler.OnPointerUp(PointerEventData eventData)
      {
            IsAutoRes = false;
            transform.GetComponent<UnityEngine.UI.Image>().color = Color.white;
            transform.GetComponentInChildren<UnityEngine.UI.Text>().color = Color.blue;
      }

      private void Start()
      {
            IsAutoRes = false;
            listRandomPalets = new List<Node>();
            listOrderedPalets = new List<Node>();
            listOfPossiblesPaletsMooves = new List<List<Node>>();

            foreach (GameObject obj in ObjType.listPalets)
            {
                  Node newNode = new Node(obj.GetComponent<Collider>());
                  listOrderedPalets.Add(newNode);
            }

            listOrderedPalets.Add(null);
      }
}
